export const lang = {
	//公共
	common: {
		//语言包名称
		name: '中文'
	}
}
