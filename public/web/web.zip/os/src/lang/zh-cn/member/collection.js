export const lang = {
	//title为每个页面的标题
	title: '我的关注',
}
